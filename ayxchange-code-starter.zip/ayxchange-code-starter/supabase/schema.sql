create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  role text not null check (role in ('student', 'mentor')),
  bio text default '',
  interests text[] not null default '{}',
  skills text[] not null default '{}',
  availability text[] not null default '{}',
  verified boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.likes (
  from_user uuid not null references public.profiles(id) on delete cascade,
  to_user uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (from_user, to_user),
  check (from_user <> to_user)
);

create table public.matches (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id),
  mentor_id uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  unique (student_id, mentor_id)
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  sender_id uuid not null references public.profiles(id),
  body text not null,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.likes enable row level security;
alter table public.matches enable row level security;
alter table public.messages enable row level security;

create policy "Profiles visible to signed-in users"
on public.profiles for select to authenticated using (true);

create policy "Users can create their own profile"
on public.profiles for insert to authenticated
with check (id = auth.uid());

create policy "Users can update their own profile"
on public.profiles for update to authenticated
using (id = auth.uid()) with check (id = auth.uid());

create policy "Users can manage likes they send"
on public.likes for all to authenticated
using (from_user = auth.uid()) with check (from_user = auth.uid());

create policy "Matched users can read their matches"
on public.matches for select to authenticated
using (student_id = auth.uid() or mentor_id = auth.uid());

create policy "Matched users can read messages"
on public.messages for select to authenticated
using (
  exists (
    select 1 from public.matches m
    where m.id = match_id
      and (m.student_id = auth.uid() or m.mentor_id = auth.uid())
  )
);

create policy "Matched users can send messages"
on public.messages for insert to authenticated
with check (
  sender_id = auth.uid()
  and exists (
    select 1 from public.matches m
    where m.id = match_id
      and (m.student_id = auth.uid() or m.mentor_id = auth.uid())
  )
);
